import 'package:flutter/material.dart';
import 'pages/home_page.dart';

void main() {
  runApp(const MishonQCApp());
}

class MishonQCApp extends StatelessWidget {
  const MishonQCApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "MishonQC AI1",
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const HomePage(),
    );
  }
}