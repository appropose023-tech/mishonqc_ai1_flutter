import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ResultPage extends StatefulWidget {
  final String imagePath;
  const ResultPage({super.key, required this.imagePath});

  @override
  State<ResultPage> createState() => _ResultPageState();
}

class _ResultPageState extends State<ResultPage> {
  String? resultText = "Processing…";

  @override
  void initState() {
    super.initState();
    sendImageToServer();
  }

  Future<void> sendImageToServer() async {
    var url = Uri.parse("http://104.154.76.47:8000/inspect");

    var request = http.MultipartRequest('POST', url)
      ..files.add(
        await http.MultipartFile.fromPath("file", widget.imagePath),
      );

    var response = await request.send();
    String body = await response.stream.bytesToString();

    setState(() {
      resultText = body;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Result")),
      body: Column(
        children: [
          Image.file(File(widget.imagePath)),
          const SizedBox(height: 20),
          Text(resultText ?? "",
              style: const TextStyle(fontSize: 18)),
        ],
      ),
    );
  }
}