class ApiService {
  static const String endpoint = "http://104.154.76.47:8000/inspect";
}
