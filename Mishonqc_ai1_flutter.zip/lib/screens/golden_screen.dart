import 'package:flutter/material.dart';

class GoldenScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text("Upload Golden Sample (GS1)"));
  }
}
