import 'package:flutter/material.dart';

class InspectScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text("Inspect Board (MS)"));
  }
}
