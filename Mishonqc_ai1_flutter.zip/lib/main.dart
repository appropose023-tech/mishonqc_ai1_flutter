import 'package:flutter/material.dart';
import 'screens/golden_screen.dart';
import 'screens/inspect_screen.dart';

void main() {
  runApp(const MishonQCApp());
}

class MishonQCApp extends StatelessWidget {
  const MishonQCApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MishonQC_AI1',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const HomeTabs(),
    );
  }
}

class HomeTabs extends StatefulWidget {
  const HomeTabs({super.key});

  @override
  State<HomeTabs> createState() => _HomeTabsState();
}

class _HomeTabsState extends State<HomeTabs> {
  int index = 0;

  final screens = [
    GoldenScreen(),
    InspectScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("MishonQC_AI1")),
      body: screens[index],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: index,
        onTap: (i)=>setState(()=>index=i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.bookmark), label: "GS1"),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: "MS"),
        ],
      ),
    );
  }
}
